#ifndef __RETARGET_H__

void RT_StreamToFile(int st);

#endif
