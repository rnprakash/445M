#define PROFILING 0

void toggle(int pin);
